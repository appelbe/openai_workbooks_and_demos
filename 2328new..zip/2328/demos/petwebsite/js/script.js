// js/script.js
document.addEventListener('DOMContentLoaded', () => {
    console.log("Pampered Pets site loaded successfully.");

    // Example: Smooth scroll for navigation links
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            console.log(`Navigating to: ${e.target.textContent}`);
        });
    });
});